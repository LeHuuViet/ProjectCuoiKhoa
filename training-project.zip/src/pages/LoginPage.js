import LoginForm from "../components/Login/LoginForm";

const LoginPage = () => {
  return (
      <LoginForm />
  );
};

export default LoginPage;
